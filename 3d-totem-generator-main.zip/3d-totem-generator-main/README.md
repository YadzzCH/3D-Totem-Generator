**3D Totem Generator**

_Creating your own totem resource pack with player skin or picture in Minecraft_
+ Creator: [Asaki Zuki](https://www.youtube.com/@main.asakizuki)
+ Translator: [Phúc Vũ](https://www.facebook.com/profile.php?id=100036150383726)

[**Website Here**](https://asakizuki.github.io/3d-totem-generator/)

![image](https://github.com/asakizuki/Custom-Totem-Skin/assets/108646953/17f785b0-0db3-4c2d-907b-0773b7148c3b)
